package com.proc.concatination;

public class Concatination {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(concatMethod("Naresh","N"));

	}

	public static String concatMethod(String FName, String LName) {
		return "Mr. " + FName + " " + LName;
	}
	public static String reverseStr(String Name){
		
		// String str = "Geeks";
		 
	        // conversion from String object to StringBuffer
	        StringBuffer sbr = new StringBuffer(Name);
	        // To reverse the string
	        sbr.reverse();
	        //System.out.println(sbr);
		return sbr.toString();

	}
}
